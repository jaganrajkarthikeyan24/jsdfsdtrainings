package sss.flipcart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlipcartApplicationTests {

	@Test
	void contextLoads() {
	}

}
