
function LogOutPage() {

    return (
        <div>Log Out page message</div>
    );
}

export default LogOutPage;