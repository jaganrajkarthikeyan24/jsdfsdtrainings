
function LoginPage() {

    return (
        <div>Loinpage</div>
    );
}

export default LoginPage;