function dis(x, y) {
console.log(x);
  if (y === undefined) {
    y = 2;
	console.log(y);
  }
}

dis(2,5);
