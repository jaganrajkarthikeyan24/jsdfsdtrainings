function varexp(){
var  x = 10;
// Here x is 10
{  
var x = 2;
// Here x is 2
}
console.log(x);
}


varexp();