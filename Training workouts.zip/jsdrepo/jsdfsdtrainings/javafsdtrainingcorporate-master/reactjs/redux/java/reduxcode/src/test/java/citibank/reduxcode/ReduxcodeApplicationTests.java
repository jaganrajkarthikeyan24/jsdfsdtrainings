package citibank.reduxcode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReduxcodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
