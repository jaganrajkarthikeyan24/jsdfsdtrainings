

export default function LogOut() {

    return (
        <h3> Loged out successfully </h3>
    )
}