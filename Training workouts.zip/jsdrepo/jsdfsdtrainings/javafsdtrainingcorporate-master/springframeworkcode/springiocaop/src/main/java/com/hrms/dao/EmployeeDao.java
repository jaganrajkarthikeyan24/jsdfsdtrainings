package com.hrms.dao;

import com.hrms.pojo.EmployeePojo;

public interface EmployeeDao {
	
	EmployeePojo getEmployee(int empId);

	EmployeePojo saveEmployee(EmployeePojo employeePojo);


}
