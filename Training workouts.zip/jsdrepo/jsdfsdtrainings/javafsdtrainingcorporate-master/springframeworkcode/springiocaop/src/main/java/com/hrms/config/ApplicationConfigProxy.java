package com.hrms.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hrms.dao.EmployeeDao;
import com.hrms.proxy.dao.EmployeeDaoImplProxy;

public class ApplicationConfigProxy {
	
	
	/*
	 * @Bean("employeeDao") public EmployeeDao getEmployeeDao() { return new
	 * EmployeeDaoImplProxy();
	 * 
	 * }
	 */


}
