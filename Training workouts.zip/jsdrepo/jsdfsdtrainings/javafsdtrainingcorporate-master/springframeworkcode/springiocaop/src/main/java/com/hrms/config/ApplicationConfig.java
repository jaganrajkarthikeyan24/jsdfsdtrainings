package com.hrms.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


public class ApplicationConfig {

	/*
	 * @Bean("employeeService") public EmployeeService getEmployeeService() { return
	 * new EmployeeServiceImpl(); }
	 * 
	 * @Bean("employeeDao") public EmployeeDao getEmployeeDao() { return new
	 * EmployeeDaoImpl();
	 * 
	 * }
	 */

}
