package com.ba.discoveryEurekaServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoveryEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
