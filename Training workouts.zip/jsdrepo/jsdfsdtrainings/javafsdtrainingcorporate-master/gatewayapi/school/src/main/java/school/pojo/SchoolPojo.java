package school.pojo;

public class SchoolPojo {
	
	
	private String schoolId;
	private String schoolName;
	private CustomerPojo customerPojo;
	public String getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(String schoolId) {
		this.schoolId = schoolId;
	}
	public String getSchoolName() {
		return schoolName;
	}
	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}
	public CustomerPojo getCustomerPojo() {
		return customerPojo;
	}
	public void setCustomerPojo(CustomerPojo customerPojo) {
		this.customerPojo = customerPojo;
	}


	
}
