package icicisecurity.icicisec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IcicisecApplicationTests {

	@Test
	void contextLoads() {
	}

}
