package icici.corebanking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CorebankingApplicationTests {

	@Test
	void contextLoads() {
	}

}
