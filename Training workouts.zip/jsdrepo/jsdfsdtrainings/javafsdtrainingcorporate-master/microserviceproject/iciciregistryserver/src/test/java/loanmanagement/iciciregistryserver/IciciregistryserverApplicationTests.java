package loanmanagement.iciciregistryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IciciregistryserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
