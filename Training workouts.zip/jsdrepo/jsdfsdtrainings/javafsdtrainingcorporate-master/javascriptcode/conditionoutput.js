function AuthButton() {
  let auth = false;

  return auth ? "hi":"uou are not logged in";
}

console.log(AuthButton());


