// destructuring

/*
let num = [1,2,3,4,5]

console.log(num[0]);

[f,t,...rest] = [1,2,3,4,5]

console.log(f);

console.log(t);

console.log(...rest);
*/

({ a, b , c } = { a: 10, b: 20,c:"adhi" });
console.log(a); // 10
console.log(b); // 20
console.log(c); // 20



rest/spread
https://javascript.info/rest-parameters-spread



